Maowei Hua 学术个人主页 — GitHub Pages 发布说明

GitHub 用户名：tonyhua3am
仓库名：tonyhua3am.github.io
部署完成后的网站地址：https://tonyhua3am.github.io/
当前交付是本地网站文件，尚未发布上线。

1. 登录 GitHub 后，打开 https://github.com/new
   Owner 选择 tonyhua3am。
   Repository name 填写 tonyhua3am.github.io。
   选择 Public，勾选 Add a README file，然后 Create repository。

2. 解压网站 ZIP。在仓库中点击 Add file → Upload files。
   上传 index.html、style.css、cv.html、favicon.svg、portrait.png。
   .nojekyll 如果可见，也一起上传；纯 HTML 网站不依赖这个文件。
   这些文件必须直接在仓库根目录，不能放在多余的一层文件夹里。
   点击 Commit changes。不要只上传 ZIP 文件。

3. 进入仓库 Settings → Pages。
   Build and deployment → Source 选择 Deploy from a branch。
   Branch 选择 main，文件夹选择 / (root)，点击 Save。

4. 等待部署完成，在 Settings → Pages 中点击 Visit site。
   部署状态也可以在 Actions 页面查看。
   网站地址为 https://tonyhua3am.github.io/
   尚未部署完成时出现 404 属于预期；若部署失败，查看 Actions 错误。

本地预览
双击 index.html 即可打开。网站不依赖构建工具、外部字体或 CDN。
cv.html 是公开版简历，点击 Print / Save as PDF 后可在浏览器选择“另存为 PDF”。

内容与维护
- 英文页面依据用户提供的简历整理。教育、论文状态沿用原简历，未独立核实。
- 两篇工作论文与在研项目明确分开，没有将审稿中的论文列为已发表论文。
- 原简历标注 Updated June 2026，同时已列出 2026 年 9 月开始的硕士“in progress”。本页按简历该经历展示；若入学状态变化，请更新。
- 首页保留邮箱；公开版 CV 未包含手机号及推荐人的联系方式。原始 PDF 不在发布包中。
- 研究兴趣由已有项目概括；没有补写论文摘要、研究发现、DOI 或未经提供的论文链接。
- 更新内容：编辑 index.html 和 cv.html；调整配色和排版：编辑 style.css。
- 首页字体使用系统 Arial 和 Georgia，无需下载字体。
- 页面未使用学校徽标。portrait.png 使用本人提供的白底原照，未做图像编辑。

GitHub 官方说明
https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site



